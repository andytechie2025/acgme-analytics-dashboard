import { pgTable, text, serial, integer, boolean, timestamp, jsonb, varchar } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User roles for ACGME system
export enum UserRole {
  PUBLIC = "public",
  PROGRAM_DIRECTOR = "program_director", 
  DIO = "dio", // Designated Institutional Official
  INSTITUTIONAL_COORDINATOR = "institutional_coordinator"
}

// Users table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  role: text("role").notNull(),
  institutionId: integer("institution_id"),
  programId: integer("program_id"),
  firstName: text("first_name").notNull(),
  lastName: text("last_name").notNull(),
  azureB2CId: text("azure_b2c_id"),
  createdAt: timestamp("created_at").defaultNow(),
  isActive: boolean("is_active").default(true)
});

// ACGME Institutions
export const institutions = pgTable("institutions", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  type: text("type").notNull(), // Academic Medical Center, Community Hospital, etc.
  city: text("city").notNull(),
  state: text("state").notNull(),
  region: text("region").notNull(), // Northeast, South, Midwest, West
  accreditationStatus: text("accreditation_status").notNull(),
  dioName: text("dio_name"),
  sponsorSize: text("sponsor_size"), // Small, Medium, Large
  createdAt: timestamp("created_at").defaultNow()
});

// ACGME Programs  
export const programs = pgTable("programs", {
  id: serial("id").primaryKey(),
  institutionId: integer("institution_id").notNull(),
  name: text("name").notNull(),
  specialty: text("specialty").notNull(),
  subspecialty: text("subspecialty"),
  accreditationStatus: text("accreditation_status").notNull(),
  programDirector: text("program_director"),
  trackLength: integer("track_length"), // years
  maxResidents: integer("max_residents"),
  currentResidents: integer("current_residents"),
  createdAt: timestamp("created_at").defaultNow()
});

// Residents/Fellows
export const residents = pgTable("residents", {
  id: serial("id").primaryKey(),
  programId: integer("program_id").notNull(),
  firstName: text("first_name").notNull(),
  lastName: text("last_name").notNull(),
  gender: text("gender"),
  race: text("race"),
  ethnicity: text("ethnicity"),
  medicalSchoolType: text("medical_school_type"), // US MD, US DO, IMG
  yearInProgram: integer("year_in_program"),
  status: text("status").notNull(), // Active, Graduated, Left
  startDate: timestamp("start_date"),
  endDate: timestamp("end_date"),
  createdAt: timestamp("created_at").defaultNow()
});

// Milestones tracking
export const milestones = pgTable("milestones", {
  id: serial("id").primaryKey(),
  residentId: integer("resident_id").notNull(),
  competency: text("competency").notNull(), // Patient Care, Medical Knowledge, etc.
  milestone: text("milestone").notNull(),
  level: integer("level").notNull(), // 1-5 scale
  evaluationDate: timestamp("evaluation_date").notNull(),
  academicYear: text("academic_year").notNull(),
  createdAt: timestamp("created_at").defaultNow()
});

// Participating Sites
export const participatingSites = pgTable("participating_sites", {
  id: serial("id").primaryKey(),
  programId: integer("program_id").notNull(),
  siteName: text("site_name").notNull(),
  siteType: text("site_type").notNull(),
  city: text("city").notNull(),
  state: text("state").notNull(),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow()
});

// AI Generated Dashboards
export const dashboards = pgTable("dashboards", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  title: text("title").notNull(),
  description: text("description"),
  query: text("query").notNull(), // Original natural language query
  config: jsonb("config").notNull(), // Chart config and data
  chartType: text("chart_type").notNull(),
  isPublic: boolean("is_public").default(false),
  usageCount: integer("usage_count").default(0),
  lastUsed: timestamp("last_used").defaultNow(),
  createdAt: timestamp("created_at").defaultNow()
});

// User favorites
export const userFavorites = pgTable("user_favorites", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  dashboardId: integer("dashboard_id").notNull(),
  createdAt: timestamp("created_at").defaultNow()
});

// Schema exports for validation
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true
});

export const insertInstitutionSchema = createInsertSchema(institutions).omit({
  id: true,
  createdAt: true
});

export const insertProgramSchema = createInsertSchema(programs).omit({
  id: true,
  createdAt: true
});

export const insertResidentSchema = createInsertSchema(residents).omit({
  id: true,
  createdAt: true
});

export const insertMilestoneSchema = createInsertSchema(milestones).omit({
  id: true,
  createdAt: true
});

export const insertDashboardSchema = createInsertSchema(dashboards).omit({
  id: true,
  createdAt: true,
  lastUsed: true,
  usageCount: true
});

export const insertUserFavoriteSchema = createInsertSchema(userFavorites).omit({
  id: true,
  createdAt: true
});

// Type exports
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type Institution = typeof institutions.$inferSelect;
export type InsertInstitution = z.infer<typeof insertInstitutionSchema>;
export type Program = typeof programs.$inferSelect;
export type InsertProgram = z.infer<typeof insertProgramSchema>;
export type Resident = typeof residents.$inferSelect;
export type InsertResident = z.infer<typeof insertResidentSchema>;
export type Milestone = typeof milestones.$inferSelect;
export type InsertMilestone = z.infer<typeof insertMilestoneSchema>;
export type Dashboard = typeof dashboards.$inferSelect;
export type InsertDashboard = z.infer<typeof insertDashboardSchema>;
export type UserFavorite = typeof userFavorites.$inferSelect;
export type InsertUserFavorite = z.infer<typeof insertUserFavoriteSchema>;
