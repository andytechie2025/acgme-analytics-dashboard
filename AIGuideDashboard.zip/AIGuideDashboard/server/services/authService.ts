import { UserRole, type User } from "@shared/schema";
import { storage } from "../storage";

export interface AuthUser {
  id: number;
  username: string;
  email: string;
  role: UserRole;
  firstName: string;
  lastName: string;
  institutionId?: number;
  programId?: number;
}

export class AuthService {
  async authenticateUser(email: string, password: string): Promise<AuthUser | null> {
    try {
      const user = await storage.getUserByEmail(email);
      
      if (!user || !user.isActive) {
        return null;
      }

      // In production, this would use proper password hashing
      // For demo purposes, we'll do a simple check
      if (user.password !== password) {
        return null;
      }

      return {
        id: user.id,
        username: user.username,
        email: user.email,
        role: user.role as UserRole,
        firstName: user.firstName,
        lastName: user.lastName,
        institutionId: user.institutionId || undefined,
        programId: user.programId || undefined
      };
    } catch (error) {
      console.error('Authentication error:', error);
      return null;
    }
  }

  async registerUser(userData: {
    email: string;
    password: string;
    firstName: string;
    lastName: string;
    role: UserRole;
    institutionId?: number;
    programId?: number;
  }): Promise<AuthUser> {
    const username = userData.email.split('@')[0];
    
    const user = await storage.createUser({
      username,
      email: userData.email,
      password: userData.password, // In production, hash this
      role: userData.role,
      firstName: userData.firstName,
      lastName: userData.lastName,
      institutionId: userData.institutionId,
      programId: userData.programId,
      azureB2CId: null
    });

    return {
      id: user.id,
      username: user.username,
      email: user.email,
      role: user.role as UserRole,
      firstName: user.firstName,
      lastName: user.lastName,
      institutionId: user.institutionId || undefined,
      programId: user.programId || undefined
    };
  }

  async getUserPermissions(userId: number): Promise<{
    canViewAllInstitutions: boolean;
    canViewAllPrograms: boolean;
    canViewAllResidents: boolean;
    canCreateDashboards: boolean;
    institutionId?: number;
    programId?: number;
  }> {
    const user = await storage.getUser(userId);
    if (!user) {
      throw new Error('User not found');
    }

    const role = user.role as UserRole;
    
    return {
      canViewAllInstitutions: role === UserRole.PUBLIC,
      canViewAllPrograms: role === UserRole.PUBLIC || role === UserRole.DIO,
      canViewAllResidents: role === UserRole.PUBLIC || role === UserRole.DIO,
      canCreateDashboards: true,
      institutionId: user.institutionId || undefined,
      programId: user.programId || undefined
    };
  }

  // Stub for Azure B2C integration
  async authenticateWithAzureB2C(token: string): Promise<AuthUser | null> {
    // TODO: Implement Azure B2C token validation
    // This would verify the JWT token from Azure B2C
    // and create/update the user record accordingly
    
    console.log('Azure B2C authentication not yet implemented');
    return null;
  }
}

export const authService = new AuthService();
