import { 
  users, institutions, programs, residents, milestones, participatingSites, dashboards, userFavorites,
  type User, type InsertUser, type Institution, type InsertInstitution, 
  type Program, type InsertProgram, type Resident, type InsertResident,
  type Milestone, type InsertMilestone, type Dashboard, type InsertDashboard,
  type UserFavorite, type InsertUserFavorite, UserRole
} from "@shared/schema";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Institution methods
  getInstitutions(userRole: UserRole, userId?: number): Promise<Institution[]>;
  getInstitution(id: number): Promise<Institution | undefined>;
  createInstitution(institution: InsertInstitution): Promise<Institution>;
  
  // Program methods
  getPrograms(userRole: UserRole, userId?: number, institutionId?: number): Promise<Program[]>;
  getProgram(id: number): Promise<Program | undefined>;
  createProgram(program: InsertProgram): Promise<Program>;
  
  // Resident methods
  getResidents(userRole: UserRole, userId?: number, programId?: number): Promise<Resident[]>;
  getResident(id: number): Promise<Resident | undefined>;
  createResident(resident: InsertResident): Promise<Resident>;
  
  // Milestone methods
  getMilestones(userRole: UserRole, residentId?: number, programId?: number): Promise<Milestone[]>;
  createMilestone(milestone: InsertMilestone): Promise<Milestone>;
  
  // Dashboard methods
  getDashboards(userId: number): Promise<Dashboard[]>;
  getDashboard(id: number): Promise<Dashboard | undefined>;
  createDashboard(dashboard: InsertDashboard): Promise<Dashboard>;
  updateDashboardUsage(id: number): Promise<void>;
  
  // User favorites methods
  getUserFavorites(userId: number): Promise<Dashboard[]>;
  addUserFavorite(favorite: InsertUserFavorite): Promise<UserFavorite>;
  removeUserFavorite(userId: number, dashboardId: number): Promise<void>;
  
  // Analytics methods
  getAnalyticsData(userRole: UserRole, userId?: number, filters?: any): Promise<any>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private institutions: Map<number, Institution>;
  private programs: Map<number, Program>;
  private residents: Map<number, Resident>;
  private milestones: Map<number, Milestone>;
  private dashboards: Map<number, Dashboard>;
  private userFavorites: Map<number, UserFavorite>;
  private currentId: number;

  constructor() {
    this.users = new Map();
    this.institutions = new Map();
    this.programs = new Map();
    this.residents = new Map();
    this.milestones = new Map();
    this.dashboards = new Map();
    this.userFavorites = new Map();
    this.currentId = 1;
    this.initializeData();
  }

  private initializeData() {
    // Initialize with sample ACGME data for demonstration
    // This represents the real ACGME structure with realistic data
    
    // Sample institutions
    const sampleInstitutions = [
      { name: "Johns Hopkins University", type: "Academic Medical Center", city: "Baltimore", state: "MD", region: "Northeast", accreditationStatus: "Continued Accreditation", dioName: "Dr. Sarah Johnson", sponsorSize: "Large" },
      { name: "Mayo Clinic", type: "Academic Medical Center", city: "Rochester", state: "MN", region: "Midwest", accreditationStatus: "Continued Accreditation", dioName: "Dr. Michael Chen", sponsorSize: "Large" },
      { name: "Cleveland Clinic", type: "Academic Medical Center", city: "Cleveland", state: "OH", region: "Midwest", accreditationStatus: "Continued Accreditation", dioName: "Dr. Robert Smith", sponsorSize: "Large" },
      { name: "UCLA Medical Center", type: "Academic Medical Center", city: "Los Angeles", state: "CA", region: "West", accreditationStatus: "Continued Accreditation", dioName: "Dr. Maria Garcia", sponsorSize: "Large" }
    ];

    sampleInstitutions.forEach(inst => {
      const institution: Institution = { ...inst, id: this.currentId++, createdAt: new Date(), dioName: inst.dioName, sponsorSize: inst.sponsorSize };
      this.institutions.set(institution.id, institution);
    });

    // Sample programs
    const samplePrograms = [
      { institutionId: 1, name: "Internal Medicine Residency", specialty: "Internal Medicine", subspecialty: null, accreditationStatus: "Continued Accreditation", programDirector: "Dr. Jane Wilson", trackLength: 3, maxResidents: 45, currentResidents: 42 },
      { institutionId: 1, name: "General Surgery Residency", specialty: "Surgery", subspecialty: "General Surgery", accreditationStatus: "Continued Accreditation", programDirector: "Dr. Mark Thompson", trackLength: 5, maxResidents: 20, currentResidents: 18 },
      { institutionId: 2, name: "Pediatrics Residency", specialty: "Pediatrics", subspecialty: null, accreditationStatus: "Continued Accreditation", programDirector: "Dr. Lisa Rodriguez", trackLength: 3, maxResidents: 30, currentResidents: 28 },
      { institutionId: 3, name: "Emergency Medicine Residency", specialty: "Emergency Medicine", subspecialty: null, accreditationStatus: "Continued Accreditation", programDirector: "Dr. David Kim", trackLength: 4, maxResidents: 24, currentResidents: 23 }
    ];

    samplePrograms.forEach(prog => {
      const program: Program = { 
        ...prog, 
        id: this.currentId++, 
        createdAt: new Date(),
        subspecialty: prog.subspecialty,
        programDirector: prog.programDirector,
        trackLength: prog.trackLength,
        maxResidents: prog.maxResidents,
        currentResidents: prog.currentResidents
      };
      this.programs.set(program.id, program);
    });

    // Sample residents
    const sampleResidents = [
      { programId: 5, firstName: "Emily", lastName: "Johnson", gender: "Female", race: "White", ethnicity: "Non-Hispanic", medicalSchoolType: "US MD", yearInProgram: 2, status: "Active", startDate: new Date('2023-07-01'), endDate: null },
      { programId: 5, firstName: "Michael", lastName: "Davis", gender: "Male", race: "Black", ethnicity: "Non-Hispanic", medicalSchoolType: "US MD", yearInProgram: 1, status: "Active", startDate: new Date('2024-07-01'), endDate: null },
      { programId: 6, firstName: "Sarah", lastName: "Chen", gender: "Female", race: "Asian", ethnicity: "Non-Hispanic", medicalSchoolType: "IMG", yearInProgram: 3, status: "Active", startDate: new Date('2022-07-01'), endDate: null },
      { programId: 7, firstName: "Carlos", lastName: "Martinez", gender: "Male", race: "Hispanic", ethnicity: "Hispanic", medicalSchoolType: "US DO", yearInProgram: 2, status: "Active", startDate: new Date('2023-07-01'), endDate: null }
    ];

    sampleResidents.forEach(res => {
      const resident: Resident = { 
        ...res, 
        id: this.currentId++, 
        createdAt: new Date(),
        gender: res.gender,
        race: res.race,
        ethnicity: res.ethnicity,
        medicalSchoolType: res.medicalSchoolType,
        yearInProgram: res.yearInProgram,
        startDate: res.startDate,
        endDate: res.endDate
      };
      this.residents.set(resident.id, resident);
    });

    // Sample milestones
    const competencies = ["Patient Care", "Medical Knowledge", "Practice-Based Learning", "Interpersonal and Communication Skills", "Professionalism", "Systems-Based Practice"];
    const sampleMilestones = [
      { residentId: 9, competency: "Patient Care", milestone: "PC1: Gathering Information", level: 3, evaluationDate: new Date('2024-06-15'), academicYear: "2023-2024" },
      { residentId: 9, competency: "Medical Knowledge", milestone: "MK1: Knowledge for Practice", level: 4, evaluationDate: new Date('2024-06-15'), academicYear: "2023-2024" },
      { residentId: 10, competency: "Patient Care", milestone: "PC1: Gathering Information", level: 2, evaluationDate: new Date('2024-12-15'), academicYear: "2024-2025" },
      { residentId: 11, competency: "Professionalism", milestone: "PROF1: Professional Behavior", level: 4, evaluationDate: new Date('2024-06-15'), academicYear: "2023-2024" }
    ];

    sampleMilestones.forEach(ms => {
      const milestone: Milestone = { 
        ...ms, 
        id: this.currentId++, 
        createdAt: new Date()
      };
      this.milestones.set(milestone.id, milestone);
    });

    // Create demo user
    const demoUser: User = {
      id: this.currentId++,
      username: "jdoe",
      email: "john.doe@hospital.edu",
      password: "demo123",
      role: "program_director",
      firstName: "John",
      lastName: "Doe",
      institutionId: 1,
      programId: 5,
      azureB2CId: null,
      createdAt: new Date(),
      isActive: true
    };
    this.users.set(demoUser.id, demoUser);
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.email === email);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentId++;
    const user: User = { 
      ...insertUser, 
      id, 
      createdAt: new Date(),
      isActive: true,
      institutionId: insertUser.institutionId ?? null,
      programId: insertUser.programId ?? null,
      azureB2CId: insertUser.azureB2CId ?? null
    };
    this.users.set(id, user);
    return user;
  }

  async getInstitutions(userRole: UserRole, userId?: number): Promise<Institution[]> {
    const allInstitutions = Array.from(this.institutions.values());
    
    // Row-level security based on user role
    if (userRole === UserRole.PUBLIC) {
      return allInstitutions; // Public can see all institutions
    }
    
    if (userRole === UserRole.DIO && userId) {
      const user = await this.getUser(userId);
      if (user?.institutionId) {
        return allInstitutions.filter(inst => inst.id === user.institutionId);
      }
    }
    
    return allInstitutions;
  }

  async getInstitution(id: number): Promise<Institution | undefined> {
    return this.institutions.get(id);
  }

  async createInstitution(insertInstitution: InsertInstitution): Promise<Institution> {
    const id = this.currentId++;
    const institution: Institution = { 
      ...insertInstitution, 
      id, 
      createdAt: new Date(),
      dioName: insertInstitution.dioName ?? null,
      sponsorSize: insertInstitution.sponsorSize ?? null
    };
    this.institutions.set(id, institution);
    return institution;
  }

  async getPrograms(userRole: UserRole, userId?: number, institutionId?: number): Promise<Program[]> {
    const allPrograms = Array.from(this.programs.values());
    
    if (institutionId) {
      return allPrograms.filter(program => program.institutionId === institutionId);
    }
    
    // Row-level security
    if (userRole === UserRole.PROGRAM_DIRECTOR && userId) {
      const user = await this.getUser(userId);
      if (user?.programId) {
        return allPrograms.filter(program => program.id === user.programId);
      }
    }
    
    return allPrograms;
  }

  async getProgram(id: number): Promise<Program | undefined> {
    return this.programs.get(id);
  }

  async createProgram(insertProgram: InsertProgram): Promise<Program> {
    const id = this.currentId++;
    const program: Program = { 
      ...insertProgram, 
      id, 
      createdAt: new Date(),
      subspecialty: insertProgram.subspecialty ?? null,
      programDirector: insertProgram.programDirector ?? null,
      trackLength: insertProgram.trackLength ?? null,
      maxResidents: insertProgram.maxResidents ?? null,
      currentResidents: insertProgram.currentResidents ?? null
    };
    this.programs.set(id, program);
    return program;
  }

  async getResidents(userRole: UserRole, userId?: number, programId?: number): Promise<Resident[]> {
    const allResidents = Array.from(this.residents.values());
    
    if (programId) {
      return allResidents.filter(resident => resident.programId === programId);
    }
    
    // Row-level security for program directors
    if (userRole === UserRole.PROGRAM_DIRECTOR && userId) {
      const user = await this.getUser(userId);
      if (user?.programId) {
        return allResidents.filter(resident => resident.programId === user.programId);
      }
    }
    
    return allResidents;
  }

  async getResident(id: number): Promise<Resident | undefined> {
    return this.residents.get(id);
  }

  async createResident(insertResident: InsertResident): Promise<Resident> {
    const id = this.currentId++;
    const resident: Resident = { 
      ...insertResident, 
      id, 
      createdAt: new Date(),
      gender: insertResident.gender ?? null,
      race: insertResident.race ?? null,
      ethnicity: insertResident.ethnicity ?? null,
      medicalSchoolType: insertResident.medicalSchoolType ?? null,
      yearInProgram: insertResident.yearInProgram ?? null,
      startDate: insertResident.startDate ?? null,
      endDate: insertResident.endDate ?? null
    };
    this.residents.set(id, resident);
    return resident;
  }

  async getMilestones(userRole: UserRole, residentId?: number, programId?: number): Promise<Milestone[]> {
    const allMilestones = Array.from(this.milestones.values());
    
    if (residentId) {
      return allMilestones.filter(milestone => milestone.residentId === residentId);
    }
    
    if (programId) {
      const programResidents = await this.getResidents(userRole, undefined, programId);
      const residentIds = programResidents.map(r => r.id);
      return allMilestones.filter(milestone => residentIds.includes(milestone.residentId));
    }
    
    return allMilestones;
  }

  async createMilestone(insertMilestone: InsertMilestone): Promise<Milestone> {
    const id = this.currentId++;
    const milestone: Milestone = { 
      ...insertMilestone, 
      id, 
      createdAt: new Date() 
    };
    this.milestones.set(id, milestone);
    return milestone;
  }

  async getDashboards(userId: number): Promise<Dashboard[]> {
    return Array.from(this.dashboards.values())
      .filter(dashboard => dashboard.userId === userId || dashboard.isPublic)
      .sort((a, b) => (b.lastUsed?.getTime() || 0) - (a.lastUsed?.getTime() || 0));
  }

  async getDashboard(id: number): Promise<Dashboard | undefined> {
    return this.dashboards.get(id);
  }

  async createDashboard(insertDashboard: InsertDashboard): Promise<Dashboard> {
    const id = this.currentId++;
    const dashboard: Dashboard = { 
      ...insertDashboard, 
      id, 
      usageCount: 0,
      lastUsed: new Date(),
      createdAt: new Date(),
      description: insertDashboard.description ?? null,
      isPublic: insertDashboard.isPublic ?? false
    };
    this.dashboards.set(id, dashboard);
    return dashboard;
  }

  async updateDashboardUsage(id: number): Promise<void> {
    const dashboard = this.dashboards.get(id);
    if (dashboard) {
      dashboard.usageCount = (dashboard.usageCount || 0) + 1;
      dashboard.lastUsed = new Date();
      this.dashboards.set(id, dashboard);
    }
  }

  async getUserFavorites(userId: number): Promise<Dashboard[]> {
    const favorites = Array.from(this.userFavorites.values())
      .filter(fav => fav.userId === userId)
      .sort((a, b) => (b.createdAt?.getTime() || 0) - (a.createdAt?.getTime() || 0))
      .slice(0, 3); // Top 3 favorites
    
    const dashboardIds = favorites.map(fav => fav.dashboardId);
    return Array.from(this.dashboards.values())
      .filter(dashboard => dashboardIds.includes(dashboard.id));
  }

  async addUserFavorite(insertFavorite: InsertUserFavorite): Promise<UserFavorite> {
    const id = this.currentId++;
    const favorite: UserFavorite = { 
      ...insertFavorite, 
      id, 
      createdAt: new Date() 
    };
    this.userFavorites.set(id, favorite);
    return favorite;
  }

  async removeUserFavorite(userId: number, dashboardId: number): Promise<void> {
    const favorites = Array.from(this.userFavorites.entries());
    for (const [id, favorite] of favorites) {
      if (favorite.userId === userId && favorite.dashboardId === dashboardId) {
        this.userFavorites.delete(id);
        break;
      }
    }
  }

  async getAnalyticsData(userRole: UserRole, userId?: number, filters?: any): Promise<any> {
    // Return analytics data based on user role and filters
    const institutions = await this.getInstitutions(userRole, userId);
    const programs = await this.getPrograms(userRole, userId);
    const residents = await this.getResidents(userRole, userId);
    
    return {
      totalInstitutions: institutions.length,
      totalPrograms: programs.length,
      totalResidents: residents.length,
      institutions,
      programs,
      residents
    };
  }
}

export const storage = new MemStorage();
