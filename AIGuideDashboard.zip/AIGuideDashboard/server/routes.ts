import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { aiService } from "./services/aiService";
import { authService } from "./services/authService";
import { acgmeDataService } from "./services/acgmeDataService";
import { predictiveAnalyticsService } from "./services/predictiveAnalyticsService";
import { UserRole, insertDashboardSchema, insertUserFavoriteSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Authentication routes
  app.post("/api/auth/login", async (req, res) => {
    try {
      const { email, password } = req.body;
      const user = await authService.authenticateUser(email, password);
      
      if (!user) {
        return res.status(401).json({ message: "Invalid credentials" });
      }
      
      res.json({ user, message: "Login successful" });
    } catch (error) {
      res.status(500).json({ message: "Authentication failed" });
    }
  });

  app.post("/api/auth/register", async (req, res) => {
    try {
      const userData = req.body;
      const user = await authService.registerUser(userData);
      res.json({ user, message: "Registration successful" });
    } catch (error) {
      res.status(400).json({ message: "Registration failed" });
    }
  });

  // User permissions
  app.get("/api/user/:id/permissions", async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const permissions = await authService.getUserPermissions(userId);
      res.json(permissions);
    } catch (error) {
      res.status(404).json({ message: "User not found" });
    }
  });

  // AI Dashboard Generation
  app.post("/api/dashboards/generate", async (req, res) => {
    try {
      const { query, userRole, userId } = req.body;
      
      if (!query || !userRole || !userId) {
        return res.status(400).json({ message: "Missing required fields" });
      }

      const dashboardResponse = await aiService.generateDashboard({
        query,
        userRole: userRole as UserRole,
        userId: parseInt(userId)
      });

      // Save the generated dashboard
      const dashboard = await storage.createDashboard({
        userId: parseInt(userId),
        title: dashboardResponse.title,
        description: dashboardResponse.description,
        query,
        config: dashboardResponse.config,
        chartType: dashboardResponse.chartType,
        isPublic: false
      });

      res.json({
        dashboard,
        insights: dashboardResponse.insights
      });
    } catch (error) {
      console.error('Dashboard generation error:', error);
      res.status(500).json({ 
        message: error instanceof Error ? error.message : "Failed to generate dashboard" 
      });
    }
  });

  // Get AI query suggestions
  app.get("/api/ai/suggestions/:userRole", async (req, res) => {
    try {
      const userRole = req.params.userRole as UserRole;
      const suggestions = await aiService.suggestQueries(userRole);
      res.json({ suggestions });
    } catch (error) {
      res.status(500).json({ message: "Failed to get suggestions" });
    }
  });

  // Dashboard CRUD operations
  app.get("/api/dashboards/user/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const dashboards = await storage.getDashboards(userId);
      res.json(dashboards);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch dashboards" });
    }
  });

  app.get("/api/dashboards/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const dashboard = await storage.getDashboard(id);
      
      if (!dashboard) {
        return res.status(404).json({ message: "Dashboard not found" });
      }

      // Update usage count
      await storage.updateDashboardUsage(id);
      
      res.json(dashboard);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch dashboard" });
    }
  });

  // User favorites
  app.get("/api/favorites/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const favorites = await storage.getUserFavorites(userId);
      res.json(favorites);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch favorites" });
    }
  });

  app.post("/api/favorites", async (req, res) => {
    try {
      const favoriteData = insertUserFavoriteSchema.parse(req.body);
      const favorite = await storage.addUserFavorite(favoriteData);
      res.json(favorite);
    } catch (error) {
      res.status(400).json({ message: "Invalid favorite data" });
    }
  });

  app.delete("/api/favorites/:userId/:dashboardId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const dashboardId = parseInt(req.params.dashboardId);
      await storage.removeUserFavorite(userId, dashboardId);
      res.json({ message: "Favorite removed" });
    } catch (error) {
      res.status(500).json({ message: "Failed to remove favorite" });
    }
  });

  // Predictive Analytics endpoints - must come before general analytics route
  app.get("/api/analytics/predictions/:userRole", async (req, res) => {
    try {
      const userRole = req.params.userRole as UserRole;
      const category = req.query.category as string;
      const insights = await predictiveAnalyticsService.generatePredictiveInsights(userRole, category);
      res.json(insights);
    } catch (error) {
      res.status(500).json({ message: "Failed to generate predictive insights" });
    }
  });

  app.get("/api/analytics/trends/:category", async (req, res) => {
    try {
      const category = req.params.category;
      const periods = parseInt(req.query.periods as string) || 3;
      const trendAnalysis = await predictiveAnalyticsService.performTrendAnalysis(category, periods);
      res.json(trendAnalysis);
    } catch (error) {
      res.status(500).json({ message: "Failed to perform trend analysis" });
    }
  });

  app.get("/api/analytics/benchmarks/:userRole/:userId", async (req, res) => {
    try {
      const userRole = req.params.userRole as UserRole;
      const userId = parseInt(req.params.userId);
      const benchmarks = await predictiveAnalyticsService.generateBenchmarkingData(userRole, userId);
      res.json(benchmarks);
    } catch (error) {
      res.status(500).json({ message: "Failed to generate benchmarking data" });
    }
  });

  // Analytics data endpoints
  app.get("/api/analytics/:userRole/:userId", async (req, res) => {
    try {
      const userRole = req.params.userRole as UserRole;
      const userId = parseInt(req.params.userId);
      const data = await storage.getAnalyticsData(userRole, userId);
      res.json(data);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch analytics data" });
    }
  });

  // Real ACGME data endpoints
  app.get("/api/acgme/data", async (req, res) => {
    try {
      const forceRefresh = req.query.refresh === 'true';
      const acgmeData = await acgmeDataService.fetchACGMEData(forceRefresh);
      res.json(acgmeData);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch ACGME data" });
    }
  });

  app.get("/api/acgme/category/:category", async (req, res) => {
    try {
      const category = req.params.category;
      const categoryData = await acgmeDataService.getDataForCategory(category);
      res.json(categoryData);
    } catch (error) {
      res.status(500).json({ message: `Failed to fetch ${category} data` });
    }
  });

  app.get("/api/acgme/sources", async (req, res) => {
    try {
      const sources = acgmeDataService.getDataSources();
      res.json(sources);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch data sources" });
    }
  });

  // ACGME data endpoints
  app.get("/api/institutions/:userRole/:userId", async (req, res) => {
    try {
      const userRole = req.params.userRole as UserRole;
      const userId = parseInt(req.params.userId);
      const institutions = await storage.getInstitutions(userRole, userId);
      res.json(institutions);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch institutions" });
    }
  });

  app.get("/api/programs/:userRole/:userId", async (req, res) => {
    try {
      const userRole = req.params.userRole as UserRole;
      const userId = parseInt(req.params.userId);
      const institutionId = req.query.institutionId ? parseInt(req.query.institutionId as string) : undefined;
      const programs = await storage.getPrograms(userRole, userId, institutionId);
      res.json(programs);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch programs" });
    }
  });

  app.get("/api/residents/:userRole/:userId", async (req, res) => {
    try {
      const userRole = req.params.userRole as UserRole;
      const userId = parseInt(req.params.userId);
      const programId = req.query.programId ? parseInt(req.query.programId as string) : undefined;
      const residents = await storage.getResidents(userRole, userId, programId);
      res.json(residents);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch residents" });
    }
  });

  app.get("/api/milestones/:userRole", async (req, res) => {
    try {
      const userRole = req.params.userRole as UserRole;
      const residentId = req.query.residentId ? parseInt(req.query.residentId as string) : undefined;
      const programId = req.query.programId ? parseInt(req.query.programId as string) : undefined;
      const milestones = await storage.getMilestones(userRole, residentId, programId);
      res.json(milestones);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch milestones" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
