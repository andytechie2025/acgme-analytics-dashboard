# ACGME Analytics Platform - Complete Codebase Manifest

## Core Application Files (Download These)

### Frontend Files (`client/`)
```
client/
├── index.html                          # Main HTML template with Tailwind CSS
├── src/
│   ├── App.tsx                         # Main app router and navigation
│   ├── main.tsx                        # React application entry point
│   ├── index.css                       # Global styles and Tailwind configuration
│   ├── components/
│   │   ├── dashboard/
│   │   │   ├── DashboardGrid.tsx       # Main dashboard with ACGME data panel
│   │   │   ├── AIPromptInterface.tsx   # Natural language query interface
│   │   │   └── AdvancedChartViewer.tsx # Chart.js visualization component
│   │   └── ui/                         # Shadcn/ui component library (auto-generated)
│   ├── hooks/
│   │   ├── use-dashboard.tsx           # Dashboard and analytics data hooks
│   │   ├── use-toast.ts                # Toast notification system
│   │   └── use-mobile.tsx              # Mobile device detection
│   ├── lib/
│   │   ├── queryClient.ts              # TanStack Query configuration
│   │   ├── utils.ts                    # Utility functions
│   │   └── types.ts                    # Frontend TypeScript types
│   └── pages/
│       ├── dashboard.tsx               # Main dashboard page
│       └── not-found.tsx               # 404 error page
```

### Backend Files (`server/`)
```
server/
├── index.ts                            # Express server setup and middleware
├── routes.ts                           # RESTful API endpoints
├── vite.ts                            # Development server integration
├── storage.ts                         # Data access layer with storage interface
└── services/
    ├── acgmeDataService.ts            # Real ACGME data integration (8 endpoints)
    ├── aiService.ts                   # OpenAI dashboard generation service
    ├── authService.ts                 # Authentication with Azure B2C integration
    └── predictiveAnalyticsService.ts   # Advanced analytics and trend analysis
```

### Shared Schema (`shared/`)
```
shared/
└── schema.ts                          # Drizzle ORM schema and TypeScript types
```

### Configuration Files (Root Directory)
```
├── package.json                       # Dependencies and build scripts
├── package-lock.json                  # Dependency lock file
├── vite.config.ts                     # Vite build configuration
├── tailwind.config.ts                 # Tailwind CSS configuration
├── tsconfig.json                      # TypeScript configuration
├── drizzle.config.ts                  # Database configuration
├── postcss.config.js                  # PostCSS configuration
├── components.json                    # Shadcn/ui configuration
└── .gitignore                         # Git ignore rules
```

### Asset Files
```
attached_assets/
└── image_1752641116255.png           # US map image for geographic visualization
```

### Documentation Files (Newly Created)
```
├── ACGME_Analytics_Design_Document.md # Complete technical documentation
├── SETUP_INSTRUCTIONS.md              # Quick setup and deployment guide
├── CODEBASE_MANIFEST.md               # This file - complete file listing
└── replit.md                          # Project overview and architecture notes
```

## Essential Files for Production Deployment

### Must Have - Core Application
1. **All `client/` files** - Complete React frontend
2. **All `server/` files** - Complete Express backend
3. **`shared/schema.ts`** - Database schema and types
4. **`package.json`** - Dependencies and scripts
5. **Configuration files** - vite.config.ts, tailwind.config.ts, tsconfig.json
6. **`attached_assets/image_1752641116255.png`** - US map for geographic visualization

### Must Configure - Environment
1. **`.env` file** - API keys and database connections (create from template)
2. **Database setup** - PostgreSQL for production (optional for demo)

### Documentation Package
1. **`ACGME_Analytics_Design_Document.md`** - Complete technical specifications
2. **`SETUP_INSTRUCTIONS.md`** - Setup and deployment guide
3. **`replit.md`** - Project architecture overview

## File Sizes and Dependencies

### Total Project Size: ~2.5MB (excluding node_modules)
- Frontend: ~1.8MB
- Backend: ~500KB
- Configuration: ~100KB
- Documentation: ~100KB

### Key Dependencies (Auto-installed via package.json)
- **Frontend**: React, TypeScript, Tailwind CSS, Chart.js, TanStack Query
- **Backend**: Express, TypeScript, OpenAI SDK, Drizzle ORM
- **Development**: Vite, ESBuild, PostCSS

## Download Instructions

### From Replit
1. Click three dots menu → "Download as ZIP"
2. Extract and follow `SETUP_INSTRUCTIONS.md`

### File-by-File Download
If ZIP download unavailable, manually copy these essential files:
1. All files listed in "Must Have - Core Application" section above
2. Create `.env` file from template in `SETUP_INSTRUCTIONS.md`
3. Run `npm install` to restore dependencies

### Verification Checklist
After download, verify you have:
- [ ] Complete `client/` directory with all components
- [ ] Complete `server/` directory with all services
- [ ] `shared/schema.ts` file
- [ ] All configuration files (package.json, vite.config.ts, etc.)
- [ ] US map image in `attached_assets/`
- [ ] Documentation files
- [ ] Created `.env` file with your API keys

The platform is ready for deployment once all files are downloaded and environment variables are configured.