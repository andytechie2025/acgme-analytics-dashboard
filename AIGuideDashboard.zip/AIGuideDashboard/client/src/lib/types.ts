import { UserRole } from "@shared/schema";

export interface AuthUser {
  id: number;
  username: string;
  email: string;
  role: UserRole;
  firstName: string;
  lastName: string;
  institutionId?: number;
  programId?: number;
}

export interface DashboardConfig {
  labels: string[];
  datasets: {
    label: string;
    data: number[];
    borderColor?: string;
    backgroundColor?: string | string[];
    tension?: number;
  }[];
}

export interface GeneratedDashboard {
  id: number;
  title: string;
  description: string;
  chartType: 'line' | 'bar' | 'pie' | 'doughnut' | 'area' | 'scatter';
  config: DashboardConfig;
  query: string;
  usageCount: number;
  lastUsed: Date;
  createdAt: Date;
}

export interface AIResponse {
  dashboard: GeneratedDashboard;
  insights: string[];
}

export interface QuickPrompt {
  id: string;
  text: string;
  category: string;
}
