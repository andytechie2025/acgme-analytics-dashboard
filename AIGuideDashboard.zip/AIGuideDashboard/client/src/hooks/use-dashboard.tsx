import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import type { AuthUser, GeneratedDashboard, AIResponse } from "@/lib/types";
import { UserRole } from "@shared/schema";

export function useDashboardGeneration(user: AuthUser | null) {
  const queryClient = useQueryClient();
  
  const generateMutation = useMutation({
    mutationFn: async (query: string): Promise<AIResponse> => {
      if (!user) throw new Error("User not authenticated");
      
      const response = await apiRequest("POST", "/api/dashboards/generate", {
        query,
        userRole: user.role,
        userId: user.id
      });
      
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/dashboards/user', user?.id] });
    }
  });

  return {
    generateDashboard: generateMutation.mutate,
    isGenerating: generateMutation.isPending,
    error: generateMutation.error,
    data: generateMutation.data
  };
}

export function useUserDashboards(userId: number | undefined) {
  return useQuery({
    queryKey: ['/api/dashboards/user', userId],
    enabled: !!userId
  });
}

export function useFavoriteDashboards(userId: number | undefined) {
  return useQuery({
    queryKey: ['/api/favorites', userId],
    enabled: !!userId
  });
}

export function useAISuggestions(userRole: UserRole) {
  return useQuery({
    queryKey: ['/api/ai/suggestions', userRole]
  });
}

export function useFavoriteActions(userId: number | undefined) {
  const queryClient = useQueryClient();
  
  const addFavorite = useMutation({
    mutationFn: async (dashboardId: number) => {
      if (!userId) throw new Error("User not authenticated");
      
      const response = await apiRequest("POST", "/api/favorites", {
        userId,
        dashboardId
      });
      
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/favorites', userId] });
    }
  });

  const removeFavorite = useMutation({
    mutationFn: async (dashboardId: number) => {
      if (!userId) throw new Error("User not authenticated");
      
      const response = await apiRequest("DELETE", `/api/favorites/${userId}/${dashboardId}`);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/favorites', userId] });
    }
  });

  return {
    addFavorite: addFavorite.mutate,
    removeFavorite: removeFavorite.mutate,
    isAdding: addFavorite.isPending,
    isRemoving: removeFavorite.isPending
  };
}

export function useAnalyticsData(userRole: UserRole, userId: number | undefined) {
  return useQuery({
    queryKey: ['/api/analytics', userRole, userId],
    enabled: !!userId
  });
}
