import { useState, useEffect } from "react";
import { TopNavigation } from "@/components/layout/TopNavigation";
import { MobileNavigation } from "@/components/layout/MobileNavigation";
import { AIPromptInterface } from "@/components/dashboard/AIPromptInterface";
import { DashboardGrid } from "@/components/dashboard/DashboardGrid";
import { FavoriteDashboards } from "@/components/dashboard/FavoriteDashboards";
import { RealTimeACGMEPanel } from "@/components/dashboard/RealTimeACGMEPanel";
import { useToast } from "@/hooks/use-toast";
import type { AuthUser } from "@/lib/types";
import { UserRole } from "@shared/schema";

export default function Dashboard() {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [activeTab, setActiveTab] = useState("home");
  const [dashboardsRefreshKey, setDashboardsRefreshKey] = useState(0);
  const { toast } = useToast();

  useEffect(() => {
    // Initialize with a demo user for development
    // In production, this would come from authentication
    const demoUser: AuthUser = {
      id: 1,
      username: "jdoe",
      email: "john.doe@hospital.edu",
      role: UserRole.PROGRAM_DIRECTOR,
      firstName: "John",
      lastName: "Doe",
      institutionId: 1,
      programId: 1
    };
    setUser(demoUser);
  }, []);

  const handleSignOut = () => {
    setUser(null);
    toast({
      title: "Signed Out",
      description: "You have been successfully signed out."
    });
  };

  const handleDashboardGenerated = () => {
    setDashboardsRefreshKey(prev => prev + 1);
  };

  const handleDashboardClick = (dashboardId: number) => {
    // In a real app, this would navigate to the specific dashboard view
    toast({
      title: "Dashboard Opened",
      description: `Opening dashboard ${dashboardId}`
    });
  };

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="max-w-md w-full space-y-8 p-8">
          <div className="text-center">
            <h2 className="mt-6 text-3xl font-extrabold text-gray-900">
              ACGME Analytics AI
            </h2>
            <p className="mt-2 text-sm text-gray-600">
              Sign in to access your personalized analytics dashboard
            </p>
          </div>
          <div className="space-y-4">
            <button
              onClick={() => {
                const demoUser: AuthUser = {
                  id: 1,
                  username: "jdoe",
                  email: "john.doe@hospital.edu",
                  role: UserRole.PROGRAM_DIRECTOR,
                  firstName: "John",
                  lastName: "Doe",
                  institutionId: 1,
                  programId: 1
                };
                setUser(demoUser);
              }}
              className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-primary hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
            >
              Demo Sign In (Program Director)
            </button>
            <p className="text-xs text-center text-gray-500">
              In production, this would integrate with Azure B2C
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <TopNavigation user={user} onSignOut={handleSignOut} />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 pb-20 sm:pb-6">
        <div className="space-y-6">
          {/* Real-time ACGME Data Panel */}
          <RealTimeACGMEPanel />
          
          {/* AI Dashboard Generation */}
          <AIPromptInterface 
            user={user} 
            onDashboardGenerated={handleDashboardGenerated}
          />
          
          {/* Analytics Grid */}
          <DashboardGrid user={user} key={dashboardsRefreshKey} />
          
          {/* User Favorites */}
          <FavoriteDashboards 
            user={user} 
            onDashboardClick={handleDashboardClick}
          />
        </div>
      </main>
      
      <MobileNavigation 
        activeTab={activeTab} 
        onTabChange={setActiveTab} 
      />
    </div>
  );
}
