import * as React from "react";
import { cn } from "@/lib/utils";

export interface ChartConfig {
  [key: string]: {
    label?: string;
    color?: string;
    theme?: {
      light?: string;
      dark?: string;
    };
  };
}

export interface ChartContainerProps
  extends React.HTMLAttributes<HTMLDivElement> {
  config: ChartConfig;
  children: React.ComponentProps<"div">["children"];
}

const ChartContainer = React.forwardRef<HTMLDivElement, ChartContainerProps>(
  ({ className, config, children, ...props }, ref) => {
    const id = React.useId();

    return (
      <div
        ref={ref}
        className={cn(
          "relative w-full h-full",
          className
        )}
        {...props}
        style={
          {
            "--color-1": "hsl(var(--chart-1))",
            "--color-2": "hsl(var(--chart-2))",
            "--color-3": "hsl(var(--chart-3))",
            "--color-4": "hsl(var(--chart-4))",
            "--color-5": "hsl(var(--chart-5))",
            ...Object.entries(config).reduce((acc, [key, value]) => {
              if (value.color) {
                acc[`--color-${key}`] = value.color;
              }
              return acc;
            }, {} as Record<string, string>),
          } as React.CSSProperties
        }
      >
        {children}
      </div>
    );
  }
);
ChartContainer.displayName = "ChartContainer";

export interface ChartTooltipProps {
  active?: boolean;
  payload?: any[];
  label?: string;
  config: ChartConfig;
  className?: string;
  hideLabel?: boolean;
  hideIndicator?: boolean;
  indicator?: "line" | "dot" | "dashed";
  labelKey?: string;
  labelClassName?: string;
  labelFormatter?: (value: any, payload: any[]) => React.ReactNode;
  formatter?: (value: any, name: string, item: any) => React.ReactNode;
}

const ChartTooltip: React.FC<ChartTooltipProps> = ({
  active,
  payload,
  label,
  config,
  className,
  hideLabel = false,
  hideIndicator = false,
  indicator = "dot",
  labelKey,
  labelClassName,
  labelFormatter,
  formatter,
}) => {
  if (!active || !payload?.length) {
    return null;
  }

  const tooltipLabel = labelFormatter
    ? labelFormatter(label, payload)
    : labelKey
    ? payload[0]?.payload?.[labelKey]
    : label;

  return (
    <div
      className={cn(
        "rounded-lg border bg-popover px-3 py-2 text-sm shadow-md",
        className
      )}
    >
      {!hideLabel && tooltipLabel && (
        <div className={cn("mb-2 font-medium", labelClassName)}>
          {tooltipLabel}
        </div>
      )}
      <div className="grid gap-2">
        {payload.map((item, index) => {
          const key = `${item.dataKey || item.name || "value"}-${index}`;
          const itemConfig = config[item.dataKey] || config[item.name];
          const indicatorColor = item.color || itemConfig?.color;

          return (
            <div key={key} className="flex items-center gap-2">
              {!hideIndicator && (
                <div
                  className={cn(
                    "shrink-0 rounded-full",
                    {
                      "h-2.5 w-2.5": indicator === "dot",
                      "h-1 w-4": indicator === "line",
                      "h-2.5 w-2.5 border-2 border-dashed bg-transparent":
                        indicator === "dashed",
                    }
                  )}
                  style={{
                    backgroundColor: indicator === "dashed" ? "transparent" : indicatorColor,
                    borderColor: indicator === "dashed" ? indicatorColor : undefined,
                  }}
                />
              )}
              <div className="flex flex-1 justify-between leading-none">
                <span className="text-muted-foreground">
                  {itemConfig?.label || item.name}
                </span>
                <span className="font-mono font-medium tabular-nums text-foreground">
                  {formatter ? formatter(item.value, item.name, item) : item.value}
                </span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export interface ChartLegendProps {
  payload?: any[];
  config: ChartConfig;
  className?: string;
  hideIcon?: boolean;
  verticalAlign?: "top" | "bottom";
  align?: "left" | "center" | "right";
  iconType?: "line" | "rect" | "circle";
  layout?: "horizontal" | "vertical";
  wrapperStyle?: React.CSSProperties;
}

const ChartLegend: React.FC<ChartLegendProps> = ({
  payload,
  config,
  className,
  hideIcon = false,
  verticalAlign = "bottom",
  align = "center",
  iconType = "rect",
  layout = "horizontal",
  wrapperStyle,
}) => {
  if (!payload?.length) {
    return null;
  }

  return (
    <div
      className={cn(
        "flex gap-4 text-sm",
        {
          "justify-start": align === "left",
          "justify-center": align === "center",
          "justify-end": align === "right",
          "flex-col": layout === "vertical",
          "flex-row": layout === "horizontal",
        },
        className
      )}
      style={wrapperStyle}
    >
      {payload.map((item, index) => {
        const key = `${item.dataKey || item.value}-${index}`;
        const itemConfig = config[item.dataKey] || config[item.value];

        return (
          <div key={key} className="flex items-center gap-2">
            {!hideIcon && (
              <div
                className={cn(
                  "shrink-0",
                  {
                    "h-3 w-3 rounded-sm": iconType === "rect",
                    "h-3 w-3 rounded-full": iconType === "circle",
                    "h-[2px] w-4": iconType === "line",
                  }
                )}
                style={{
                  backgroundColor: item.color || itemConfig?.color,
                }}
              />
            )}
            <span className="text-muted-foreground">
              {itemConfig?.label || item.value}
            </span>
          </div>
        );
      })}
    </div>
  );
};

export {
  ChartContainer,
  ChartTooltip,
  ChartLegend,
};
