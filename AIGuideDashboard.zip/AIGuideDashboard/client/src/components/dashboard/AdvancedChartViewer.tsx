import React, { useState, useEffect } from 'react';
import { 
  Chart as ChartJS, 
  CategoryScale, 
  LinearScale, 
  BarElement, 
  LineElement, 
  PointElement, 
  ArcElement, 
  Title, 
  Tooltip, 
  Legend,
  Filler
} from 'chart.js';
import { Bar, Line, Pie, Doughnut } from 'react-chartjs-2';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { MoreHorizontal, Download, Share2, RefreshCw, TrendingUp } from "lucide-react";
import { GeneratedDashboard } from "@/lib/types";

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  LineElement,
  PointElement,
  ArcElement,
  Title,
  Tooltip,
  Legend,
  Filler
);

interface AdvancedChartViewerProps {
  dashboard: GeneratedDashboard;
  onRefresh?: () => void;
  showActions?: boolean;
}

export function AdvancedChartViewer({ 
  dashboard, 
  onRefresh, 
  showActions = true 
}: AdvancedChartViewerProps) {
  const [isAnimating, setIsAnimating] = useState(true);
  const [showInsights, setShowInsights] = useState(true);

  useEffect(() => {
    // Trigger animation on mount
    const timer = setTimeout(() => setIsAnimating(false), 500);
    return () => clearTimeout(timer);
  }, [dashboard.id]);

  const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    animation: {
      duration: isAnimating ? 1000 : 0,
      easing: 'easeInOutQuart' as const
    },
    plugins: {
      legend: {
        position: 'top' as const,
        labels: {
          usePointStyle: true,
          padding: 20,
          font: {
            size: 12,
            family: "'Inter', sans-serif"
          }
        }
      },
      tooltip: {
        backgroundColor: 'rgba(15, 23, 42, 0.9)',
        titleColor: '#f8fafc',
        bodyColor: '#e2e8f0',
        borderColor: '#334155',
        borderWidth: 1,
        cornerRadius: 8,
        padding: 12,
        displayColors: true,
        callbacks: {
          title: function(context: any) {
            return `${context[0].label}`;
          },
          label: function(context: any) {
            const value = context.parsed.y || context.parsed;
            const total = context.dataset.data.reduce((a: number, b: number) => a + b, 0);
            const percentage = dashboard.chartType === 'pie' || dashboard.chartType === 'doughnut' 
              ? ` (${((value / total) * 100).toFixed(1)}%)`
              : '';
            return `${context.dataset.label}: ${value.toLocaleString()}${percentage}`;
          }
        }
      }
    },
    scales: dashboard.chartType === 'line' || dashboard.chartType === 'bar' ? {
      y: {
        beginAtZero: true,
        grid: {
          color: 'rgba(148, 163, 184, 0.1)',
          drawBorder: false
        },
        ticks: {
          color: '#64748b',
          font: {
            size: 11,
            family: "'Inter', sans-serif"
          },
          callback: function(value: any) {
            return value >= 1000 ? `${(value / 1000).toFixed(1)}K` : value;
          }
        }
      },
      x: {
        grid: {
          display: false
        },
        ticks: {
          color: '#64748b',
          font: {
            size: 11,
            family: "'Inter', sans-serif"
          },
          maxRotation: 45
        }
      }
    } : undefined
  };

  const renderChart = () => {
    const { chartType, config } = dashboard;
    
    switch (chartType) {
      case 'bar':
        return <Bar data={config} options={chartOptions} />;
      case 'line':
        return <Line data={config} options={chartOptions} />;
      case 'pie':
        return <Pie data={config} options={chartOptions} />;
      case 'doughnut':
        return <Doughnut data={config} options={chartOptions} />;
      default:
        return <Bar data={config} options={chartOptions} />;
    }
  };

  const handleExport = () => {
    // In a real implementation, this would export the chart as PNG/PDF
    console.log('Exporting chart...');
  };

  const handleShare = () => {
    // In a real implementation, this would generate a shareable link
    console.log('Sharing dashboard...');
  };

  const getChartTypeIcon = () => {
    switch (dashboard.chartType) {
      case 'line':
        return <TrendingUp className="h-4 w-4" />;
      default:
        return <MoreHorizontal className="h-4 w-4" />;
    }
  };

  return (
    <Card className="w-full transition-all duration-300 hover:shadow-lg">
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between">
          <div className="space-y-1">
            <CardTitle className="text-xl font-semibold tracking-tight">
              {dashboard.title}
            </CardTitle>
            <CardDescription className="text-sm text-muted-foreground">
              {dashboard.description}
            </CardDescription>
          </div>
          {showActions && (
            <div className="flex items-center gap-2">
              <Badge variant="secondary" className="text-xs">
                {getChartTypeIcon()}
                {dashboard.chartType}
              </Badge>
              <div className="flex items-center gap-1">
                {onRefresh && (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={onRefresh}
                    className="h-8 w-8 p-0"
                  >
                    <RefreshCw className="h-4 w-4" />
                  </Button>
                )}
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={handleShare}
                  className="h-8 w-8 p-0"
                >
                  <Share2 className="h-4 w-4" />
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={handleExport}
                  className="h-8 w-8 p-0"
                >
                  <Download className="h-4 w-4" />
                </Button>
              </div>
            </div>
          )}
        </div>
      </CardHeader>
      
      <CardContent className="space-y-4">
        {/* Chart Container */}
        <div className="relative h-64 w-full">
          {renderChart()}
        </div>
        
        {/* Insights Section */}
        {showInsights && dashboard.insights && dashboard.insights.length > 0 && (
          <div className="space-y-2">
            <h4 className="text-sm font-medium text-foreground">Key Insights</h4>
            <div className="grid gap-2">
              {dashboard.insights.map((insight, index) => (
                <div
                  key={index}
                  className="flex items-start gap-2 rounded-lg bg-muted/50 p-3 text-sm"
                >
                  <div className="mt-0.5 h-2 w-2 rounded-full bg-primary flex-shrink-0" />
                  <span className="text-muted-foreground leading-relaxed">
                    {insight}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}
        
        {/* Metadata */}
        <div className="flex items-center justify-between text-xs text-muted-foreground pt-2 border-t">
          <span>
            Generated {new Date(dashboard.createdAt).toLocaleDateString()}
          </span>
          <span>
            Used {dashboard.usageCount} time{dashboard.usageCount !== 1 ? 's' : ''}
          </span>
        </div>
      </CardContent>
    </Card>
  );
}