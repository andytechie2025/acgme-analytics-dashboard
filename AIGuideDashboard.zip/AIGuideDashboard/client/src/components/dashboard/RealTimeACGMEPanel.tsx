import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { 
  Database, 
  TrendingUp, 
  Users, 
  Building, 
  GraduationCap, 
  RefreshCw,
  CheckCircle,
  AlertCircle,
  Activity
} from "lucide-react";

interface ACGMEData {
  programs: {
    total: number;
    bySpecialty: Record<string, number>;
    byState: Record<string, number>;
    growthTrends: Array<{ year: string; count: number }>;
  };
  residents: {
    total: number;
    byGender: Record<string, number>;
    byRaceEthnicity: Record<string, number>;
  };
  institutions: {
    total: number;
    bySize: Record<string, number>;
  };
}

interface RealTimeACGMEPanelProps {
  onDataUpdate?: (data: ACGMEData) => void;
}

export function RealTimeACGMEPanel({ onDataUpdate }: RealTimeACGMEPanelProps) {
  const [lastUpdate, setLastUpdate] = useState<Date>(new Date());
  const [connectionStatus, setConnectionStatus] = useState<'connected' | 'loading' | 'error'>('loading');

  const { data: acgmeData, isLoading, error, refetch } = useQuery({
    queryKey: ['/api/acgme/data'],
    refetchInterval: 5 * 60 * 1000, // Refetch every 5 minutes
    refetchIntervalInBackground: false,
    refetchOnWindowFocus: true,
    onSuccess: (data) => {
      setLastUpdate(new Date());
      setConnectionStatus('connected');
      onDataUpdate?.(data);
    },
    onError: () => {
      setConnectionStatus('error');
    }
  });

  const { data: dataSources } = useQuery({
    queryKey: ['/api/acgme/sources']
  });

  useEffect(() => {
    if (isLoading) {
      setConnectionStatus('loading');
    } else if (error) {
      setConnectionStatus('error');
    } else {
      setConnectionStatus('connected');
    }
  }, [isLoading, error]);

  const handleRefresh = () => {
    refetch();
  };

  const getLatestGrowth = () => {
    if (!acgmeData?.programs?.growthTrends) return null;
    const trends = acgmeData.programs.growthTrends;
    if (trends.length < 2) return null;
    
    const latest = trends[trends.length - 1];
    const previous = trends[trends.length - 2];
    const growth = ((latest.count - previous.count) / previous.count) * 100;
    
    return {
      current: latest.count,
      previous: previous.count,
      growth: growth.toFixed(1),
      year: latest.year
    };
  };

  const getTopSpecialties = () => {
    if (!acgmeData?.programs?.bySpecialty) return [];
    return Object.entries(acgmeData.programs.bySpecialty)
      .sort(([,a], [,b]) => b - a)
      .slice(0, 3);
  };

  const getGenderDistribution = () => {
    if (!acgmeData?.residents?.byGender) return null;
    const total = Object.values(acgmeData.residents.byGender).reduce((sum, count) => sum + count, 0);
    const female = acgmeData.residents.byGender.Female || 0;
    const male = acgmeData.residents.byGender.Male || 0;
    
    return {
      total,
      femalePercent: ((female / total) * 100).toFixed(1),
      malePercent: ((male / total) * 100).toFixed(1)
    };
  };

  const getConnectionStatusIcon = () => {
    switch (connectionStatus) {
      case 'connected':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'loading':
        return <Activity className="h-4 w-4 text-blue-500 animate-pulse" />;
      case 'error':
        return <AlertCircle className="h-4 w-4 text-red-500" />;
    }
  };

  const growthData = getLatestGrowth();
  const topSpecialties = getTopSpecialties();
  const genderData = getGenderDistribution();

  return (
    <Card className="w-full">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div className="space-y-1">
            <CardTitle className="text-lg font-semibold flex items-center gap-2">
              <Database className="h-5 w-5 text-primary" />
              Real-Time ACGME Data
            </CardTitle>
            <CardDescription className="text-sm">
              Live data from {dataSources?.length || 8} ACGME public sources
            </CardDescription>
          </div>
          <div className="flex items-center gap-2">
            <Badge variant="outline" className="text-xs">
              {getConnectionStatusIcon()}
              {connectionStatus}
            </Badge>
            <Button
              variant="ghost"
              size="sm"
              onClick={handleRefresh}
              disabled={isLoading}
              className="h-8 w-8 p-0"
            >
              <RefreshCw className={`h-4 w-4 ${isLoading ? 'animate-spin' : ''}`} />
            </Button>
          </div>
        </div>
      </CardHeader>

      <CardContent className="space-y-4">
        {isLoading ? (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[...Array(4)].map((_, i) => (
              <Card key={i}>
                <CardContent className="p-4">
                  <Skeleton className="h-4 w-full mb-2" />
                  <Skeleton className="h-8 w-3/4" />
                </CardContent>
              </Card>
            ))}
          </div>
        ) : error ? (
          <div className="text-center py-8 text-muted-foreground">
            <AlertCircle className="h-8 w-8 mx-auto mb-2" />
            <p>Failed to load ACGME data</p>
            <Button variant="outline" onClick={handleRefresh} className="mt-2">
              Retry
            </Button>
          </div>
        ) : (
          <>
            {/* Key Metrics Grid */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1">
                    <GraduationCap className="h-4 w-4" />
                    Total Programs
                  </div>
                  <div className="text-2xl font-bold">
                    {acgmeData?.programs?.total?.toLocaleString() || '0'}
                  </div>
                  {growthData && (
                    <div className="text-xs text-green-600 flex items-center gap-1 mt-1">
                      <TrendingUp className="h-3 w-3" />
                      +{growthData.growth}% from {parseInt(growthData.year) - 1}
                    </div>
                  )}
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1">
                    <Users className="h-4 w-4" />
                    Total Residents
                  </div>
                  <div className="text-2xl font-bold">
                    {acgmeData?.residents?.total?.toLocaleString() || '0'}
                  </div>
                  {genderData && (
                    <div className="text-xs text-muted-foreground mt-1">
                      {genderData.femalePercent}% F / {genderData.malePercent}% M
                    </div>
                  )}
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1">
                    <Building className="h-4 w-4" />
                    Institutions
                  </div>
                  <div className="text-2xl font-bold">
                    {acgmeData?.institutions?.total?.toLocaleString() || '0'}
                  </div>
                  <div className="text-xs text-muted-foreground mt-1">
                    Sponsoring organizations
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1">
                    <Activity className="h-4 w-4" />
                    Data Sources
                  </div>
                  <div className="text-2xl font-bold">
                    {dataSources?.length || 8}
                  </div>
                  <div className="text-xs text-muted-foreground mt-1">
                    Active endpoints
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Top Specialties */}
            {topSpecialties.length > 0 && (
              <div className="space-y-2">
                <h4 className="text-sm font-medium">Top Medical Specialties</h4>
                <div className="grid gap-2">
                  {topSpecialties.map(([specialty, count], index) => (
                    <div key={specialty} className="flex items-center justify-between p-2 rounded-lg bg-muted/50">
                      <div className="flex items-center gap-2">
                        <Badge variant="outline" className="w-6 h-6 rounded-full p-0 flex items-center justify-center text-xs">
                          {index + 1}
                        </Badge>
                        <span className="text-sm font-medium">{specialty}</span>
                      </div>
                      <span className="text-sm text-muted-foreground">
                        {count.toLocaleString()} programs
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Last Update */}
            <div className="flex items-center justify-between text-xs text-muted-foreground pt-2 border-t">
              <span>
                Last updated: {lastUpdate.toLocaleTimeString()}
              </span>
              <span>
                Next refresh in 5 minutes
              </span>
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
}