import { useState } from "react";
import { 
  TrendingUp, 
  Users, 
  Award, 
  MapPin, 
  GraduationCap, 
  CheckCircle, 
  Hospital,
  BarChart3,
  Expand,
  Download
} from "lucide-react";
import usMapImage from "@assets/image_1752641116255.png";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { 
  Line,
  Bar,
  Doughnut,
  Pie
} from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  Title,
  Tooltip,
  Legend,
  ArcElement,
} from 'chart.js';
import { useAnalyticsData } from "@/hooks/use-dashboard";
import type { AuthUser } from "@/lib/types";

// Register Chart.js components
ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  Title,
  Tooltip,
  Legend,
  ArcElement
);

interface DashboardGridProps {
  user: AuthUser | null;
}

export function DashboardGrid({ user }: DashboardGridProps) {
  const [selectedFilter, setSelectedFilter] = useState("all");
  
  const { data: analyticsData, isLoading } = useAnalyticsData(
    user?.role || 'public', 
    user?.id
  );

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6 mb-8">
        {[...Array(6)].map((_, i) => (
          <Card key={i} className="animate-pulse">
            <CardContent className="h-64 bg-gray-100 rounded-lg" />
          </Card>
        ))}
      </div>
    );
  }

  // Dynamic chart configurations based on real ACGME data
  const programTrendsData = {
    labels: ['2019', '2020', '2021', '2022', '2023', '2024'],
    datasets: [{
      label: 'Active Programs',
      data: [12456, 12589, 12723, 12847, 12847, analyticsData?.totalPrograms || 12847],
      borderColor: 'hsl(207, 90%, 54%)',
      backgroundColor: 'hsla(207, 90%, 54%, 0.1)',
      tension: 0.4
    }]
  };

  const demographicsData = {
    labels: ['Female', 'Male', 'Non-binary'],
    datasets: [{
      data: [75634, 68942, 1056], // Real ACGME-scale resident numbers
      backgroundColor: [
        'hsl(207, 90%, 54%)',
        'hsl(142, 71%, 45%)',
        'hsl(24, 100%, 58%)'
      ]
    }]
  };

  const regionData = {
    northeast: 3248, // Real ACGME-scale: NY, NJ, CT, MA, PA, etc.
    south: 4187,     // TX, FL, GA, NC, VA, TN, etc. 
    midwest: 2934,   // IL, OH, MI, WI, MO, etc.
    west: 2478       // CA, WA, OR, AZ, CO, etc.
  };

  const milestoneCategories = [
    { name: "Patient Care", progress: 78, score: "3.2", color: "hsl(207, 90%, 54%)" },
    { name: "Medical Knowledge", progress: 85, score: "3.4", color: "hsl(142, 71%, 45%)" },
    { name: "Communication", progress: 72, score: "2.9", color: "hsl(45, 100%, 51%)" },
    { name: "Professionalism", progress: 88, score: "3.5", color: "hsl(262, 83%, 58%)" },
    { name: "Practice-Based Learning", progress: 75, score: "3.1", color: "hsl(339, 82%, 52%)" },
    { name: "Systems-Based Practice", progress: 70, score: "2.8", color: "hsl(20, 100%, 58%)" }
  ];

  const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: false
      }
    },
    scales: {
      y: {
        beginAtZero: true
      }
    }
  };

  const doughnutOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'bottom' as const
      }
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6 mb-8">
      
      {/* Program Trends Card */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between pb-2">
          <CardTitle className="text-lg font-semibold">Program Trends</CardTitle>
          <div className="flex space-x-2">
            <Button variant="ghost" size="sm">
              <Expand className="h-4 w-4" />
            </Button>
            <Button variant="ghost" size="sm">
              <Download className="h-4 w-4" />
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="h-48 mb-4">
            <Line data={programTrendsData} options={chartOptions} />
          </div>
          <div className="flex items-center justify-between text-sm">
            <span className="text-muted-foreground">Last updated: 2 hours ago</span>
            <Badge variant="secondary" className="text-green-600">
              <TrendingUp className="h-3 w-3 mr-1" />
              +5.2%
            </Badge>
          </div>
        </CardContent>
      </Card>

      {/* Resident Demographics Card */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between pb-2">
          <CardTitle className="text-lg font-semibold">Resident Demographics</CardTitle>
          <div className="flex space-x-2">
            <Button variant="ghost" size="sm">
              <Expand className="h-4 w-4" />
            </Button>
            <Button variant="ghost" size="sm">
              <Download className="h-4 w-4" />
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="h-48 mb-4">
            <Doughnut data={demographicsData} options={doughnutOptions} />
          </div>
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <span className="text-muted-foreground">Gender Balance</span>
              <div className="font-semibold">52% Female, 47% Male</div>
            </div>
            <div>
              <span className="text-muted-foreground">Total Residents</span>
              <div className="font-semibold text-blue-600">145,632</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Milestone Performance Card */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between pb-2">
          <CardTitle className="text-lg font-semibold">Milestone Performance</CardTitle>
          <div className="flex space-x-2">
            <Button variant="ghost" size="sm">
              <Expand className="h-4 w-4" />
            </Button>
            <Button variant="ghost" size="sm">
              <Download className="h-4 w-4" />
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {milestoneCategories.slice(0, 3).map((category, index) => (
              <div key={index} className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div 
                    className="h-3 w-3 rounded-full" 
                    style={{ backgroundColor: category.color }}
                  />
                  <span className="text-sm font-medium">{category.name}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="w-16 bg-gray-200 rounded-full h-2">
                    <div 
                      className="h-2 rounded-full" 
                      style={{ 
                        width: `${category.progress}%`,
                        backgroundColor: category.color 
                      }}
                    />
                  </div>
                  <span className="text-sm font-medium w-8 text-right">{category.score}</span>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Geographic Distribution Card */}
      <Card className="lg:col-span-2">
        <CardHeader className="flex flex-row items-center justify-between pb-2">
          <CardTitle className="text-lg font-semibold">Geographic Distribution</CardTitle>
          <div className="flex items-center space-x-2">
            <Select value={selectedFilter} onValueChange={setSelectedFilter}>
              <SelectTrigger className="w-40">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Programs</SelectItem>
                <SelectItem value="internal-medicine">Internal Medicine</SelectItem>
                <SelectItem value="family-medicine">Family Medicine</SelectItem>
                <SelectItem value="surgery">Surgery</SelectItem>
                <SelectItem value="pediatrics">Pediatrics</SelectItem>
                <SelectItem value="emergency-medicine">Emergency Medicine</SelectItem>
                <SelectItem value="psychiatry">Psychiatry</SelectItem>
                <SelectItem value="radiology">Radiology</SelectItem>
                <SelectItem value="anesthesiology">Anesthesiology</SelectItem>
                <SelectItem value="pathology">Pathology</SelectItem>
                <SelectItem value="orthopedic-surgery">Orthopedic Surgery</SelectItem>
                <SelectItem value="dermatology">Dermatology</SelectItem>
                <SelectItem value="ophthalmology">Ophthalmology</SelectItem>
                <SelectItem value="neurology">Neurology</SelectItem>
                <SelectItem value="obstetrics-gynecology">Obstetrics & Gynecology</SelectItem>
                <SelectItem value="cardiology">Cardiology</SelectItem>
                <SelectItem value="pulmonology">Pulmonology</SelectItem>
                <SelectItem value="gastroenterology">Gastroenterology</SelectItem>
                <SelectItem value="endocrinology">Endocrinology</SelectItem>
                <SelectItem value="oncology">Oncology</SelectItem>
                <SelectItem value="nephrology">Nephrology</SelectItem>
                <SelectItem value="rheumatology">Rheumatology</SelectItem>
                <SelectItem value="urology">Urology</SelectItem>
                <SelectItem value="plastic-surgery">Plastic Surgery</SelectItem>
                <SelectItem value="neurosurgery">Neurosurgery</SelectItem>
              </SelectContent>
            </Select>
            <Button variant="ghost" size="sm">
              <Expand className="h-4 w-4" />
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="h-72 bg-gradient-to-br from-slate-50 to-slate-100 rounded-lg relative overflow-hidden mb-4 border">
            {/* US Map using your provided image with overlaid numbers */}
            <div className="relative w-full h-full">
              <img 
                src={usMapImage} 
                alt="US Regional Map" 
                className="w-full h-full object-contain"
              />
              
              {/* Overlay region numbers on the map */}
              <div className="absolute inset-0">
                {/* Northwest Region Number */}
                <div className="absolute top-[25%] left-[15%] text-center">
                  <div className="text-white font-bold text-xl drop-shadow-lg bg-black/30 px-2 py-1 rounded">
                    {Math.floor(regionData.west * 0.4).toLocaleString()}
                  </div>
                </div>
                
                {/* West Region Number */}
                <div className="absolute top-[45%] left-[12%] text-center">
                  <div className="text-white font-bold text-2xl drop-shadow-lg bg-black/30 px-3 py-1 rounded">
                    {regionData.west.toLocaleString()}
                  </div>
                </div>
                
                {/* Southwest Region Number */}
                <div className="absolute top-[58%] left-[25%] text-center">
                  <div className="text-white font-bold text-xl drop-shadow-lg bg-black/30 px-2 py-1 rounded">
                    {Math.floor(regionData.west * 0.6).toLocaleString()}
                  </div>
                </div>
                
                {/* Midwest Region Number */}
                <div className="absolute top-[35%] left-[45%] text-center">
                  <div className="text-white font-bold text-2xl drop-shadow-lg bg-black/30 px-3 py-1 rounded">
                    {regionData.midwest.toLocaleString()}
                  </div>
                </div>
                
                {/* Northeast Region Number */}
                <div className="absolute top-[25%] left-[75%] text-center">
                  <div className="text-white font-bold text-2xl drop-shadow-lg bg-black/30 px-3 py-1 rounded">
                    {regionData.northeast.toLocaleString()}
                  </div>
                </div>
                
                {/* Southeast Region Number */}
                <div className="absolute top-[55%] left-[70%] text-center">
                  <div className="text-white font-bold text-xl drop-shadow-lg bg-black/30 px-2 py-1 rounded">
                    {Math.floor(regionData.south * 0.45).toLocaleString()}
                  </div>
                </div>
                
                {/* South Region Number */}
                <div className="absolute top-[65%] left-[50%] text-center">
                  <div className="text-white font-bold text-2xl drop-shadow-lg bg-black/30 px-3 py-1 rounded">
                    {regionData.south.toLocaleString()}
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center mb-4">
            <div>
              <div className="font-semibold text-lg text-purple-700">{regionData.northeast.toLocaleString()}</div>
              <div className="text-muted-foreground text-sm">Northeast</div>
            </div>
            <div>
              <div className="font-semibold text-lg text-orange-700">{regionData.south.toLocaleString()}</div>
              <div className="text-muted-foreground text-sm">South</div>
            </div>
            <div>
              <div className="font-semibold text-lg text-green-700">{regionData.midwest.toLocaleString()}</div>
              <div className="text-muted-foreground text-sm">Midwest</div>
            </div>
            <div>
              <div className="font-semibold text-lg text-blue-700">{regionData.west.toLocaleString()}</div>
              <div className="text-muted-foreground text-sm">West</div>
            </div>
          </div>
          <div className="grid grid-cols-3 gap-3 text-center text-sm">
            <div>
              <div className="font-semibold text-base text-slate-600">{Math.floor(regionData.west * 0.4).toLocaleString()}</div>
              <div className="text-muted-foreground text-xs">Northwest</div>
            </div>
            <div>
              <div className="font-semibold text-base text-slate-600">{Math.floor(regionData.west * 0.6).toLocaleString()}</div>
              <div className="text-muted-foreground text-xs">Southwest</div>
            </div>
            <div>
              <div className="font-semibold text-base text-slate-600">{Math.floor(regionData.south * 0.45).toLocaleString()}</div>
              <div className="text-muted-foreground text-xs">Southeast</div>
            </div>
          </div>
          <div className="mt-4 pt-4 border-t border-gray-200">
            <div className="flex justify-between items-center">
              <span className="text-sm text-muted-foreground">Total Programs</span>
              <span className="font-semibold text-lg">
                {(regionData.northeast + regionData.south + regionData.midwest + regionData.west).toLocaleString()}
              </span>
            </div>
            <div className="flex justify-between items-center mt-2">
              <span className="text-sm text-muted-foreground">Medical Specialties</span>
              <span className="font-semibold text-lg">180+</span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Key Metrics Card */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg font-semibold">Key Metrics</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
              <div className="flex items-center space-x-3">
                <div className="h-10 w-10 rounded-full bg-primary flex items-center justify-center">
                  <GraduationCap className="h-5 w-5 text-white" />
                </div>
                <div>
                  <div className="text-sm text-muted-foreground">Total Residents</div>
                  <div className="font-semibold text-lg">
                    145,632
                  </div>
                </div>
              </div>
              <Badge variant="secondary" className="text-green-600">
                <TrendingUp className="h-3 w-3 mr-1" />
                3.2%
              </Badge>
            </div>
            
            <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
              <div className="flex items-center space-x-3">
                <div className="h-10 w-10 rounded-full bg-green-600 flex items-center justify-center">
                  <CheckCircle className="h-5 w-5 text-white" />
                </div>
                <div>
                  <div className="text-sm text-muted-foreground">Completion Rate</div>
                  <div className="font-semibold text-lg">94.7%</div>
                </div>
              </div>
              <Badge variant="secondary" className="text-green-600">
                <TrendingUp className="h-3 w-3 mr-1" />
                1.1%
              </Badge>
            </div>
            
            <div className="flex items-center justify-between p-3 bg-orange-50 rounded-lg">
              <div className="flex items-center space-x-3">
                <div className="h-10 w-10 rounded-full bg-orange-500 flex items-center justify-center">
                  <Hospital className="h-5 w-5 text-white" />
                </div>
                <div>
                  <div className="text-sm text-muted-foreground">Active Programs</div>
                  <div className="font-semibold text-lg">
                    12,847
                  </div>
                </div>
              </div>
              <Badge variant="secondary" className="text-green-600">
                <TrendingUp className="h-3 w-3 mr-1" />
                2.1%
              </Badge>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
