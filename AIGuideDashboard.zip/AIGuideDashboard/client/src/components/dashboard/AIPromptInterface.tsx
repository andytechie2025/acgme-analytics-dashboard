import { useState } from "react";
import { Send, Mic, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { AdvancedChartViewer } from "./AdvancedChartViewer";
import { useDashboardGeneration, useAISuggestions } from "@/hooks/use-dashboard";
import { useToast } from "@/hooks/use-toast";
import type { AuthUser } from "@/lib/types";

interface AIPromptInterfaceProps {
  user: AuthUser | null;
  onDashboardGenerated: () => void;
}

export function AIPromptInterface({ user, onDashboardGenerated }: AIPromptInterfaceProps) {
  const [query, setQuery] = useState("");
  const { toast } = useToast();
  
  const { generateDashboard, isGenerating, error, data } = useDashboardGeneration(user);
  const { data: suggestions } = useAISuggestions(user?.role || 'public');

  const handleGenerate = () => {
    if (!query.trim()) {
      toast({
        title: "Query Required",
        description: "Please enter a question about your ACGME data.",
        variant: "destructive"
      });
      return;
    }

    if (!user) {
      toast({
        title: "Authentication Required",
        description: "Please sign in to generate dashboards.",
        variant: "destructive"
      });
      return;
    }

    generateDashboard(query.trim(), {
      onSuccess: () => {
        setQuery("");
        onDashboardGenerated();
        toast({
          title: "Dashboard Generated",
          description: "Your AI-powered dashboard has been created successfully."
        });
      },
      onError: () => {
        toast({
          title: "Generation Failed",
          description: error?.message || "Failed to generate dashboard. Please try again.",
          variant: "destructive"
        });
      }
    });
  };

  const handleQuickPrompt = (promptText: string) => {
    setQuery(promptText);
  };

  const quickPrompts = suggestions?.suggestions || [
    "Show program trends over the last 3 years",
    "Analyze resident demographics by specialty",
    "Compare milestone performance across competencies",
    "Display geographic distribution of programs"
  ];

  return (
    <Card className="mb-8">
      <CardContent className="p-6">
        <div className="flex items-center mb-4">
          <div className="h-10 w-10 rounded-full bg-accent flex items-center justify-center mr-3">
            <Sparkles className="h-5 w-5 text-white" />
          </div>
          <div>
            <h2 className="text-lg font-semibold text-gray-900">
              AI Dashboard Generator
            </h2>
            <p className="text-sm text-gray-600">
              Ask me anything about your ACGME data
            </p>
          </div>
        </div>

        <div className="relative">
          <Textarea
            placeholder="e.g., 'Show me residency completion rates by specialty for the last 3 years' or 'Compare our program's milestone performance to national averages'"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="resize-none pr-20"
            rows={3}
            disabled={isGenerating}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) {
                handleGenerate();
              }
            }}
          />
          <div className="absolute bottom-3 right-3 flex space-x-2">
            <Button variant="ghost" size="sm" disabled={isGenerating}>
              <Mic className="h-4 w-4" />
            </Button>
            <Button 
              size="sm" 
              onClick={handleGenerate}
              disabled={!query.trim() || isGenerating}
            >
              <Send className="h-4 w-4 mr-2" />
              {isGenerating ? "Generating..." : "Generate"}
            </Button>
          </div>
        </div>

        <div className="mt-4 flex flex-wrap gap-2">
          <span className="text-xs text-gray-500 mr-2">Quick prompts:</span>
          {quickPrompts.slice(0, 4).map((prompt, index) => (
            <Badge
              key={index}
              variant="secondary"
              className="cursor-pointer hover:bg-gray-200 transition-colors"
              onClick={() => handleQuickPrompt(prompt)}
            >
              {prompt.length > 30 ? `${prompt.substring(0, 30)}...` : prompt}
            </Badge>
          ))}
        </div>

        {data && (
          <div className="mt-6 space-y-4">
            <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
              <h4 className="font-medium text-green-900 mb-2">
                ✨ Dashboard Created: {data.dashboard.title}
              </h4>
              <p className="text-sm text-green-700 mb-2">
                {data.dashboard.description}
              </p>
              {data.insights && data.insights.length > 0 && (
                <div className="text-sm">
                  <strong className="text-green-900">Key Insights:</strong>
                  <ul className="list-disc list-inside text-green-700 mt-1">
                    {data.insights.map((insight, index) => (
                      <li key={index}>{insight}</li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
            
            {/* Display the generated chart */}
            <AdvancedChartViewer 
              dashboard={data.dashboard} 
              showActions={true}
            />
          </div>
        )}

        {error && (
          <div className="mt-4 p-4 bg-red-50 border border-red-200 rounded-lg">
            <h4 className="font-medium text-red-900 mb-1">
              Generation Failed
            </h4>
            <p className="text-sm text-red-700">
              {error.message || "Unable to generate dashboard. Please try rephrasing your query or check your permissions."}
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
