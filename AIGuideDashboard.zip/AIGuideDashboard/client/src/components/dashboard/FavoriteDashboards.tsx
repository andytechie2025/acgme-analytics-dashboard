import { Star, ExternalLink, Settings } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useFavoriteDashboards, useFavoriteActions } from "@/hooks/use-dashboard";
import type { AuthUser } from "@/lib/types";

interface FavoriteDashboardsProps {
  user: AuthUser | null;
  onDashboardClick: (dashboardId: number) => void;
}

export function FavoriteDashboards({ user, onDashboardClick }: FavoriteDashboardsProps) {
  const { data: favorites, isLoading } = useFavoriteDashboards(user?.id);
  const { addFavorite, removeFavorite } = useFavoriteActions(user?.id);

  if (!user || isLoading) {
    return null;
  }

  const favoriteDashboards = favorites || [];

  // Recent activity mock data - in production this would come from API
  const recentActivity = [
    {
      id: 1,
      title: 'Generated "Residency Completion Trends"',
      timestamp: '2 hours ago',
      type: 'generation'
    },
    {
      id: 2,
      title: 'Created "Milestone Performance Analysis"',
      timestamp: '5 hours ago',
      type: 'creation'
    },
    {
      id: 3,
      title: 'Updated "Geographic Distribution Report"',
      timestamp: '1 day ago',
      type: 'update'
    }
  ];

  return (
    <div className="space-y-8">
      {/* Recent Activity */}
      <Card>
        <div className="p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold">Recent Dashboard Activity</h3>
            <Button variant="ghost" size="sm">
              View All
            </Button>
          </div>
          <div className="space-y-3">
            {recentActivity.map((activity) => (
              <div key={activity.id} className="flex items-center space-x-4 p-3 hover:bg-gray-50 rounded-lg transition-colors">
                <div className="h-10 w-10 rounded-full bg-gray-100 flex items-center justify-center">
                  <Star className="h-5 w-5 text-gray-600" />
                </div>
                <div className="flex-1">
                  <div className="text-sm font-medium">{activity.title}</div>
                  <div className="text-xs text-muted-foreground">{activity.timestamp}</div>
                </div>
                <Button variant="ghost" size="sm">
                  <ExternalLink className="h-4 w-4" />
                </Button>
              </div>
            ))}
          </div>
        </div>
      </Card>

      {/* Favorite Dashboards - Bottom Sticky Section */}
      <div className="bg-white border-t border-gray-200 sticky bottom-0 pb-safe sm:pb-0">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between mb-3">
            <h4 className="text-sm font-medium">Your Favorite Dashboards</h4>
            <Button variant="ghost" size="sm">
              <Settings className="h-4 w-4 mr-1" />
              Manage
            </Button>
          </div>
          
          {favoriteDashboards.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {favoriteDashboards.slice(0, 3).map((dashboard, index) => (
                <button
                  key={dashboard.id}
                  onClick={() => onDashboardClick(dashboard.id)}
                  className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors text-left w-full"
                >
                  <div className="h-8 w-8 rounded-lg bg-primary flex items-center justify-center flex-shrink-0">
                    <Star className="h-4 w-4 text-white" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="text-sm font-medium text-gray-900 truncate">
                      {dashboard.title}
                    </div>
                    <div className="text-xs text-muted-foreground">
                      Used {dashboard.usageCount} time{dashboard.usageCount !== 1 ? 's' : ''} this week
                    </div>
                  </div>
                </button>
              ))}
            </div>
          ) : (
            <div className="text-center py-8 text-muted-foreground">
              <Star className="h-12 w-12 mx-auto mb-2 text-gray-300" />
              <p className="text-sm">No favorite dashboards yet</p>
              <p className="text-xs">Generate some dashboards and mark them as favorites to see them here</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
